from django.contrib import admin

# Register your models here.
from api.models import Articledata

admin.site.register(Articledata)
